
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <cstring>
#include <list>
#include <deque>
#include "Source.h"
#include <map>
#include <unordered_map>
//#include <CMATH>
#include <algorithm>
#include "Point.h"
//#include "Polygon.h"
#include <random>
#include <iterator>
//#include "Auxiliary.h"

#include <algorithm>

//#include <studio.h> 
#include <corecrt_math.h>


/*
double Polygon::distanceFromPolygon(Point point) {
	auto minDist = std::numeric_limits<double>::max();;
	auto numEdges = 4;
	for (const auto& vertex : points) {
		auto dist = pow(vertex.x - point.x, 2) + pow(vertex.y - point.y, 2);
		if (dist < minDist)
			minDist = dist;
	}
	for (auto i = 0; i < numEdges; i++) {
		auto numerator = pow((vertices[(i + 1) % numEdges].x - vertices[i].x) * (vertices[i].y - point.y) -
			(vertices[i].x - point.x) * (vertices[(i + 1) % numEdges].y - vertices[i].y), 2);
		auto denominator = pow(((vertices[(i + 1) % numEdges].x - vertices[i].x)), 2) +
			pow(((vertices[(i + 1) % numEdges].y - vertices[i].y)), 2);
		auto dist = numerator / denominator;
		if (dist < minDist)
			minDist = dist;
	}
	return minDist;
}
*/

using namespace std;
std::map<string,string>dict_of_points;
std::map<string, string>dict_of_delete_points;
std::map<string, string>dict_of_above_points;
std::map<string, string>dict_of_inside_points;

std::vector<vector <double>> vector_of_points;// vector of vectorc [[x,y,in or out,above or under,dist],[x,y,in or out,above or under,dist],...]
											  //					[0,1,2		  ,3			 ,4	  ]
std::vector<vector <double>> vector_of_above_points;
std::vector<vector <double>> vector_of_delete_points;
std::vector<vector <double>> vector_of_inside_points;
std::vector<vector <double>> vector_of_c_o_m_points;
std::vector<vector <double>> vector_of_z_filterd_points;
std::vector<vector <double>> vector_of_c_o_m_points_midians;
std::vector<vector <double>> vector_of_c_o_m_points_max_dist;

std::vector<int> pickSet(int N, int k, std::mt19937& gen)
{
	std::uniform_int_distribution<> dis(1, N);
	std::vector<int> elems;

	while (elems.size() < k) {
		elems.push_back(dis(gen));
	}

	return elems;
}

/*
//////////////////////////////////////////////////////////////////

std::vector<Point> getPointsFromFile(const std::string& fileName) {
	std::vector<Point> points;
	std::ifstream myFile(fileName);
	std::string line;
	while (std::getline(myFile, line)) {
		std::stringstream lineStream(line);
		Point point;
		lineStream >> point.x;
		if (lineStream.peek() == ',') lineStream.ignore();
		lineStream >> point.z;
		if (lineStream.peek() == ',') lineStream.ignore();
		lineStream >> point.y;
		if (lineStream.peek() == ',') lineStream.ignore();
		lineStream >> point.frameId;
		points.push_back(point);
	}
	return points;

}

std::vector<Point> leastSquaresPolygon(const std::vector<Point>& points, int k, int iterations = 1000)
{
	auto min_cost = std::numeric_limits<double>::max();
	Polygon best_polygon(points, Point());
	double cost = 0;
	std::mt19937 mt{ std::random_device{}() };
	std::vector<Point> sample_points;
	//std::vector<int> indices(points.size());
	//std::iota(indices.begin(), indices.end(), 0);

	for (std::size_t i = 0; i <= iterations; i++) {
		sample_points.clear();
		cost = 0;
		std::random_device rd;
		std::mt19937 gen(rd());
		std::vector<int> random_indexes= pickSet(points.size(), 4, gen);
		
		for (int i = 0; i <= random_indexes.size(); i++) {
			sample_points.push_back(points[random_indexes[i]]);
		}


		//::sample (points.begin(), points.end(), std::back_inserter(sample_points), k, mt);
		
		//std::cout << sample_points[0].x << std::endl;
		//std::cout << sample_points[i].to_string() << std::endl;
		//std::vector<cv::Point_<double>> sample_points_cv;
		//for (const auto& pt : sample_points) {
		//	cv::Point_<double> pt_cv(pt.x, pt.y);
		//	sample_points_cv.push_back(pt_cv);
		//}

		//std::cout << sample_points_cv[1] << std::endl;
		//std::vector<cv::Point_<double>> hull;
		//cv::convexHull(sample_points_cv, hull);

		//std::cout << "a" << std::endl;
		//if (hull.size() != k)
		//	continue;

		std::vector<Point> polygon_vertices;
		//auto map = [](cv::Point_<double> pt) { return Point(pt.x, pt.y, 0); };
		//std::transform(hull.begin(), hull.end(), std::back_inserter(polygon_vertices), map);
		Polygon polygon(points, Point());
		polygon.vertices = polygon_vertices;
		//std::cout << "a" << std::endl;
		for (const auto& pt : points) {
			cost += polygon.distanceFromPolygon(pt);
		}

		if (cost < min_cost) {
			min_cost = cost;
			best_polygon.vertices = polygon.vertices;
		}
	}
	return best_polygon.vertices;
}


/////////////////////////////////////////////////////////////////
*/


double str_to_double (string str,int i) {
	vector<string> v;
	stringstream ss(str);
	while (ss.good()) {
		string substr;
		getline(ss, substr, ',');
		v.push_back(substr);
	}
	return (std::stof(v[i]));
}

int str_to_int(string str, int i) {
	vector<string> v;
	stringstream ss(str);
	while (ss.good()) {
		string substr;
		getline(ss, substr, ',');
		v.push_back(substr);
	}
	return (std::stoi(v[i]));
}

int pnpoly(int nvert, double* vertx, double* verty, double testx, double testy)
{
	int i, j, c = 0;
	for (i = 0, j = nvert - 1; i < nvert; j = i++) {
		if (((verty[i] > testy) != (verty[j] > testy)) &&
			(testx < (vertx[j] - vertx[i]) * (testy - verty[i]) / (verty[j] - verty[i]) + vertx[i]))
			c = !c;
	}
	return c;
}

/*
std::vector<Point> getPointsFromFile(const std::string& fileName) {
	std::vector<Point> points;
	std::ifstream myFile(fileName);
	std::string line;
	while (std::getline(myFile, line)) {
		std::stringstream lineStream(line);
		Point point;
		lineStream >> point.x;
		if (lineStream.peek() == ',') lineStream.ignore();
		lineStream >> point.z;
		if (lineStream.peek() == ',') lineStream.ignore();
		lineStream >> point.y;
		if (lineStream.peek() == ',') lineStream.ignore();
		lineStream >> point.frameId;
		points.push_back(point);
	}
	return points;

}
*/

double distance_p2p(double x1, double y1, double x2, double y2)
{
	// Calculating distance
	return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2) * 1.0);
}

int file_to_vector(string myFilepath) {
	
	ifstream pointFile;
	pointFile.open(myFilepath);
	if (pointFile.fail()) {
		cerr << "unable open file" << myFilepath << endl;
		return 0;
	}
	while (pointFile.peek() != EOF) {
		string line;
		getline(pointFile, line, '\n');
		double xx = str_to_double(line, 0);
		double yy = str_to_double(line, 2);
		double point[2] = {xx,yy};
		vector_of_points.push_back({xx,yy});
	}
	pointFile.close();
	return 1;
}

int file_to_vector_with_z(string myFilepath) {
	ifstream pointFile;
	pointFile.open(myFilepath);
	if (pointFile.fail()) {
		cerr << "unable open file" << myFilepath << endl;
		return 0;
	}
	while (pointFile.peek() != EOF) {
		string line;
		getline(pointFile, line, '\n');
		double xx = str_to_double(line, 0);
		double yy = str_to_double(line, 2);
		double zz = str_to_double(line, 1);
		double point[3] = { xx,yy ,zz};
		vector_of_z_filterd_points.push_back({ xx,yy,zz});
	}
	pointFile.close();
	return 1;
}

std::vector <double> center_of_mass() {
	double sum_x = 0;
	double sum_y = 0;
	for (int itr = 0; itr < vector_of_points.size(); itr++) {
		sum_x += vector_of_points[itr][0];
		sum_y += vector_of_points[itr][1];
	}
	std::vector <double> point_center_of_mass = { (sum_x / vector_of_points.size()), (sum_y / vector_of_points.size()) };
	return point_center_of_mass;
}

int delete_far_frome_c_o_m(std::vector <double> c_o_m) {
	for (int itr = 0; itr < vector_of_points.size(); itr++) {
		double dist = distance_p2p(vector_of_points[itr][0], vector_of_points[itr][1], c_o_m[0], c_o_m[1]);
		std::vector <double> tmp_point_dist = { vector_of_points[itr][0], vector_of_points[itr][1] ,dist };
		vector_of_c_o_m_points.push_back(tmp_point_dist);
	}
	for (int i = 0; i < vector_of_c_o_m_points.size() * 0.01; i++) {
		int max_itr = 0;
		for (int itr = 0; itr < vector_of_c_o_m_points.size(); itr++) {
			if (vector_of_c_o_m_points[itr][2] > vector_of_c_o_m_points[max_itr][2]) {
				max_itr = itr;
			}
		}
		vector_of_c_o_m_points.erase(vector_of_c_o_m_points.begin() + (max_itr));
	}
	/*
	for (int i = 0; i < vector_of_c_o_m_points.size() * 0.25; i++) {
		int min_itr = 0;
		for (int itr = 0; itr < vector_of_c_o_m_points.size(); itr++) {
			if (vector_of_c_o_m_points[itr][2] < vector_of_c_o_m_points[min_itr][2]) {
				min_itr = itr;
			}
		}
		vector_of_c_o_m_points.erase(vector_of_c_o_m_points.begin() + (min_itr));
	}*/

	return 1;
}

int delete_far_frome_c_o_m_with_midian(std::vector <double> c_o_m) {
	
	for (int itr = 0; itr < vector_of_points.size(); itr++) {
		double dist = distance_p2p(vector_of_points[itr][0], vector_of_points[itr][1], c_o_m[0], c_o_m[1]);
		std::vector <double> tmp_point_dist = { vector_of_points[itr][0], vector_of_points[itr][1] ,dist };
		vector_of_c_o_m_points.push_back(tmp_point_dist);
	}
	for (double angle = 0; angle < 360; angle = angle + 2) {
		double sumX = 0;
		double sumY = 0;
		int num_of_point_for_angle = 0;
		for (int itr = 0; itr < vector_of_c_o_m_points.size(); itr++) {
			double point_angle = (180 * atan(vector_of_c_o_m_points[itr][1] / vector_of_c_o_m_points[itr][0])) / 3.14159265;
			if (vector_of_c_o_m_points[itr][0]>0 && vector_of_c_o_m_points[itr][1] > 0) {
				
			}
			else if (vector_of_c_o_m_points[itr][0] < 0 && vector_of_c_o_m_points[itr][1] > 0) {
				point_angle = 180 + point_angle;
			}
			else if (vector_of_c_o_m_points[itr][0] < 0 && vector_of_c_o_m_points[itr][1] < 0) {
				point_angle = 180 + point_angle;
			}
			else if (vector_of_c_o_m_points[itr][0] > 0 && vector_of_c_o_m_points[itr][1] < 0) {
				point_angle = 360 + point_angle;
			}
			if (point_angle > angle && point_angle < angle + 2) {
				sumX = sumX + vector_of_c_o_m_points[itr][0];
				sumY = sumY + vector_of_c_o_m_points[itr][1];
				num_of_point_for_angle++;
			}
		}
		if (num_of_point_for_angle > 0) {
			vector <double> midian_of_the_angle = { sumX / num_of_point_for_angle ,sumY / num_of_point_for_angle };
			vector_of_c_o_m_points_midians.push_back(midian_of_the_angle);
		}
	}
	return 1;
}

int delete_far_frome_c_o_m_with_max_dist(std::vector <double> c_o_m, double Angle) {

	/*for (int itr = 0; itr < vector_of_points.size(); itr++) {
		double dist = distance_p2p(vector_of_points[itr][0], vector_of_points[itr][1], c_o_m[0], c_o_m[1]);
		std::vector <double> tmp_point_dist = { vector_of_points[itr][0], vector_of_points[itr][1] ,dist };
		vector_of_c_o_m_points.push_back(tmp_point_dist);
	}*/
	for (double angle = 0; angle < 360; angle = angle + Angle) {
		int num_of_point_for_angle = 0;
		int max_index = 0;
		int max = 0;
		for (int itr = 0; itr < vector_of_c_o_m_points.size(); itr++) {
			double point_angle = (180 * atan(vector_of_c_o_m_points[itr][1] / vector_of_c_o_m_points[itr][0])) / 3.14159265;
			if (vector_of_c_o_m_points[itr][0] > 0 && vector_of_c_o_m_points[itr][1] > 0) {

			}
			else if (vector_of_c_o_m_points[itr][0] < 0 && vector_of_c_o_m_points[itr][1] > 0) {
				point_angle = 180 + point_angle;
			}
			else if (vector_of_c_o_m_points[itr][0] < 0 && vector_of_c_o_m_points[itr][1] < 0) {
				point_angle = 180 + point_angle;
			}
			else if (vector_of_c_o_m_points[itr][0] > 0 && vector_of_c_o_m_points[itr][1] < 0) {
				point_angle = 360 + point_angle;
			}
			if (point_angle > angle && point_angle < angle + Angle) {
				if (vector_of_c_o_m_points[itr][2] > max) {
					max = vector_of_c_o_m_points[itr][2];
					max_index = itr;
				}
				num_of_point_for_angle++;
			}
		}
		if (num_of_point_for_angle > 0) {
			vector <double> the_max_dist_of_the_angle = vector_of_c_o_m_points[max_index];
			vector_of_c_o_m_points_max_dist.push_back(the_max_dist_of_the_angle);
		}
		/*
		int vector_of_c_o_m_points_max_dist_size = vector_of_c_o_m_points_max_dist.size();
		for (int i = 0; i < vector_of_c_o_m_points_max_dist_size * 0.05; i++) {
			int max_itr = 0;
			for (int itr = 0; itr < vector_of_c_o_m_points_max_dist.size(); itr++) {
				if (vector_of_c_o_m_points_max_dist[itr][2] > vector_of_c_o_m_points_max_dist[max_itr][2]) {
					max_itr = itr;
				}
			}
			vector_of_c_o_m_points_max_dist.erase(vector_of_c_o_m_points_max_dist.begin() + (max_itr));
		}
		*/
	}
	return 1;
}


int delete_far_frome_z() {
	int how_mach_to_delete = vector_of_z_filterd_points.size() * 0.8;
	for (int i = 0; i < how_mach_to_delete; i++) {
		int min_itr = 0;
		for (int itr = 0; itr < vector_of_z_filterd_points.size(); itr++) {
			if (vector_of_z_filterd_points[itr][2] < vector_of_z_filterd_points[min_itr][2]) {
				min_itr = itr;
			}
		}
		vector_of_z_filterd_points.erase(vector_of_z_filterd_points.begin() + (min_itr));
	}

	return 1;
}

int checkInsidePoligon(std::vector< vector <double>> poligon_points, int n) {
	double lines_cord_x[4] = { poligon_points[0][0],poligon_points[1][0],poligon_points[2][0],poligon_points[3][0] };
	double lines_cord_y[4] = { poligon_points[0][1],poligon_points[1][1],poligon_points[2][1],poligon_points[3][1] };
	for (int itr = 0; itr < vector_of_points.size() ; itr++) {
		double xx = vector_of_points[itr][0];
		double yy = vector_of_points[itr][1];
		int in_or_out = pnpoly(4, lines_cord_x, lines_cord_y, xx, yy);
		vector_of_points[itr].push_back(in_or_out);
	}
	return 1;
}

int above_line(double* point1line, double* point2line, double* testpoint) {
	if ((point2line[0] == point1line[0])) {  //ortogonal line
		if (testpoint[0] > point2line[0]) {
			return 1;//right
		}
		return 0;  //left
	}  // inclined and parallel line
	double M = (point2line[1] - point1line[1]) / (point2line[0] - point1line[0]);
	double y = M * testpoint[0] - M * point2line[0] + point2line[1];
	if (y < testpoint[1]) {
		return 1; //up
	}
	if (y > testpoint[1]) {
		return 0; //down
	}
	return 2; //
}

void getLine(double x1, double y1, double x2, double y2, double& a, double& b, double& c)
{
	// (x- p1X) / (p2X - p1X) = (y - p1Y) / (p2Y - p1Y) 
	a = y1 - y2; // Note: this was incorrectly "y2 - y1" in the original answer
	b = x2 - x1;
	c = x1 * y2 - x2 * y1;
}

double Dist(double pct1X, double pct1Y, double pct2X, double pct2Y, double pct3X, double pct3Y)
{
	double a, b, c;
	getLine(pct2X, pct2Y, pct3X, pct3Y, a, b, c);
	return (abs(a * pct1X + b * pct1Y + c) / sqrt(a * a + b * b));
}

int delet_wall_points_for_one_line(double* point1line, double* point2line) {
	for (int itr = 0; itr < vector_of_points.size(); itr++)
	{
		for (int itr2 = 0; itr2 < 2; itr2++) {
			vector_of_points[itr].push_back(0);
		}
	}
	                            //divide the points to above or ander the line
	for (int itr = 0; itr < vector_of_points.size(); itr++)
	{
		double point_x_y[2] = {vector_of_points[itr][0],vector_of_points[itr][1] };
		if (above_line(point1line, point2line, point_x_y)) {
			vector_of_points[itr][3] = 1;
			vector_of_above_points.push_back(vector_of_points[itr]);
		}
		else {
			vector_of_points[itr][3] = 0;
		}
	}

	int under = 0;                     // decide which grop of points we need to work on
	for (int itr = 0; itr < vector_of_points.size(); itr++)
	{
		if ((vector_of_points[itr][3] == 1) && (vector_of_points[itr][2] == 1)) {
			under = 1;
			break;
		}
	}

									  //calc the dist for all points from the corent line
	for (int itr = 0; itr < vector_of_points.size(); itr++)
	{
		double dist = Dist(vector_of_points[itr][0], vector_of_points[itr][1], point1line[0], point1line[1], point2line[0], point2line[1]);
		vector_of_points[itr][4]= dist;
	}

	double sum = 0;
	int num = 0;
										//calc mean for the grop of points that relevent
	for (int itr = 0; itr < vector_of_points.size(); itr++)
	{	
		if (under && (vector_of_points[itr][3] == 0)) {
			sum += vector_of_points[itr][4];
			num++;
		} 
		else if (!under && (vector_of_points[itr][3] == 1)) {
			sum += vector_of_points[itr][4];;
			num++;
		}
	}
	double mean = sum / num;

									 // go over all the points and delete the point that inside the range by iterate
	int tmp = 0;
	int deleted_conter = 0;
	for (double factor_to_delete = 2; factor_to_delete <= 4; factor_to_delete = +factor_to_delete + 0.2) 
	{
		for (int itr = vector_of_points.size() -1; itr >=0 ;)
		{
			if (under && (vector_of_points[itr][3] == 0) && (vector_of_points[itr][4] <= (factor_to_delete * mean))) {
				vector_of_delete_points.push_back(vector_of_points[itr]);

				vector_of_points.erase( vector_of_points.begin() + (itr));
				itr--;

				deleted_conter++;
				continue;
			}
			else if (!under && (vector_of_points[itr][3] == 1) && (vector_of_points[itr][4] <= (factor_to_delete * mean))) {
				vector_of_delete_points.push_back(vector_of_points[itr]);
				vector_of_points.erase(vector_of_points.begin() + (itr));
				itr--;
				deleted_conter++;
				continue;
			}
			itr--;
		}
		double double_num = num + 0.0;
		double precent_of_deleted_points = (deleted_conter / double_num);
		if (precent_of_deleted_points > 0.95) {
			break;
		}
	}
	return 0;
}

int  delet_wall_points(int n, std::vector< vector <double>> poligon_points) {
	double Xpoint_of_all_lines[4] = { poligon_points[0][0],poligon_points[1][0],poligon_points[2][0],poligon_points[3][0] };
	double ypoint_of_all_lines[4] = { poligon_points[0][1],poligon_points[1][1],poligon_points[2][1],poligon_points[3][1] };
	for (int i = 0; i < n; i++) {
		
		double point1[2] = { Xpoint_of_all_lines[i] , ypoint_of_all_lines[i] };
		
		if (i + 1 == n) {
			double point2[2] = { Xpoint_of_all_lines[0], ypoint_of_all_lines[0] };
			delet_wall_points_for_one_line(point1, point2);
		}
		else {
			double point2[2] = { Xpoint_of_all_lines[i + 1], ypoint_of_all_lines[i + 1] };
			delet_wall_points_for_one_line(point1, point2);
		}
		
		
	}
	
	for (int itr = vector_of_points.size() - 1; itr >= 0;)
	{
		if (vector_of_points[itr][2] == 1) {
			vector_of_points.erase(vector_of_points.begin() + (itr--));
		}
		else {
			itr--;
		}
	}
	return 1;
}

int delet_inside() {
	for (int itr = vector_of_points.size()-1; itr >=0 ;)
	{
		if (vector_of_points[itr][2] == 1) {
			vector_of_inside_points.push_back(vector_of_points[itr]);
			vector_of_points.erase(vector_of_points.begin() + (itr--));
		}
		else {
			itr--;
		}
	}
	return 1;
}

double max_in_arrey(double* arr) {

	return *max_element(arr, arr + 8);

}

int calc_exits_point_sqwer(std::vector< vector <double>> poligon_points, string myFilepath , double* midel_point) {
	double Xpoint_of_all_lines[4] = { poligon_points[0][0],poligon_points[1][0],poligon_points[2][0],poligon_points[3][0] };
	double ypoint_of_all_lines[4] = { poligon_points[0][1],poligon_points[1][1],poligon_points[2][1],poligon_points[3][1] };

	string filee = myFilepath + "exit_point.csv";
	std::cout << filee;
	ofstream pointFile;
	pointFile.open(filee);
	if (pointFile.fail()) {
		cerr <<endl << endl << endl << "unable open file" << myFilepath << endl << endl << endl;
		return 0;
	}
		double point0[2] = { Xpoint_of_all_lines[0],ypoint_of_all_lines[0] };
		double point1[2] = { Xpoint_of_all_lines[1],ypoint_of_all_lines[1] };
		double point2[2] = { Xpoint_of_all_lines[2],ypoint_of_all_lines[2] };
		double point3[2] = { Xpoint_of_all_lines[3],ypoint_of_all_lines[3] };
		int line_1_above = 1; // 1 == the grup that intresting as its above, 0 == oposit
		int line_2_above = 1;
		int line_3_above = 1;
		int line_4_above = 1;
		if (above_line(point0, point1, midel_point)) {
			 line_1_above = 0;
		}
		if (above_line(point1, point2, midel_point)) {
			 line_2_above = 0;
		}
		if (above_line(point2, point3, midel_point)) {
			 line_3_above = 0;
		}
		if (above_line(point3, point0, midel_point)) {
			 line_4_above = 0;
		}
		double totx[8] = { 0,0,0,0,0,0,0,0 };
		double toty[8] = { 0,0,0,0,0,0,0,0 };
		int count[8] = { 1,1,1,1,1,1,1,1 };
		double sum_of_dist_from_line [8] = { 0,0,0,0,0,0,0,0 };
		

		//std::map<string, string>::iterator itr;
		//for (itr = dict_of_points.begin(); itr != dict_of_points.end(); itr++)
		for (int itr = 0; itr < vector_of_points.size(); itr++)
		{
			double test_point_x = vector_of_points[itr][0];
			double test_point_y = vector_of_points[itr][1];
			double test_point[2] = { test_point_x,test_point_y };
			std::cout << "for" << endl;
			if ((above_line(point0, point1, test_point) == line_1_above) && above_line(point0, point3, test_point) == line_4_above) {
				count[0]++;
				totx[0] = totx[0] + test_point[0];
				toty[0] = toty[0] + test_point[1];
				std::cout << "area 1" << endl;
				pointFile << test_point_x << "," << test_point_y << "," << ",1" << endl;
				sum_of_dist_from_line [0] = sum_of_dist_from_line[0] + Dist(test_point[0], test_point[1], point0[0], point0[1], point3[0], point3[1]);
			}
			else if ((above_line(point1, point2, test_point) == line_2_above) && above_line(point0, point1, test_point) == line_1_above) {
				count[2]++;
				totx[2] = totx[2] + test_point[0];
				toty[2] = toty[2] + test_point[1];
				std::cout << "area 3" << endl;
				pointFile << test_point_x << "," << test_point_y << "," << ",3" << endl;
				sum_of_dist_from_line[2] = sum_of_dist_from_line[2] + Dist(test_point[0], test_point[1], point0[0], point0[1], point1[0], point1[1]);
			}
			else if ((above_line(point2, point3, test_point) == line_3_above) && above_line(point1, point2, test_point) == line_2_above) {
				count[4]++;
				totx[4] = totx[4] + test_point[0];
				toty[4] = toty[4] + test_point[1];
				std::cout << "area 5" << endl;
				pointFile << test_point_x << "," << test_point_y << "," << ",5" << endl;
				sum_of_dist_from_line[4] = sum_of_dist_from_line[4] + Dist(test_point[0], test_point[1], point1[0], point1[1], point2[0], point2[1]);
			}
			else if ((above_line(point2, point3, test_point) == line_3_above) && above_line(point0, point3, test_point) == line_4_above) {
				count[6]++;
				totx[6] = totx[6] + test_point[0];
				toty[6] = toty[6] + test_point[1];
				std::cout << "area 7" << endl;
				pointFile << test_point_x << "," << test_point_y << "," << ",7" << endl;
				sum_of_dist_from_line[6] = sum_of_dist_from_line[6] + Dist(test_point[0], test_point[1], point2[0], point2[1], point3[0], point3[1]);
			}
			else if ((above_line(point0, point1, test_point) == line_1_above) && above_line(point0, point3, test_point) != line_4_above && above_line(point1, point2, test_point) != line_2_above) {
				count[1]++;
				totx[1] = totx[1] + test_point[0];
				toty[1] = toty[1] + test_point[1];
				std::cout << "area 2" << endl;
				pointFile << test_point_x << "," << test_point_y << "," << ",2" << endl;
				sum_of_dist_from_line[1] = sum_of_dist_from_line[1] + distance_p2p(point0[0], point0[1], test_point[0], test_point[1]);
			}
			else if ((above_line(point0, point1, test_point) != line_1_above) && above_line(point2, point3, test_point) != line_3_above && above_line(point1, point2, test_point) == line_2_above) {
				count[3]++;
				totx[3] = totx[3] + test_point[0];
				toty[3] = toty[3] + test_point[1];
				std::cout << "area 4" << endl;
				pointFile << test_point_x << "," << test_point_y << "," << ",4" << endl;
				sum_of_dist_from_line[3] = sum_of_dist_from_line[3] + distance_p2p(point1[0], point1[1], test_point[0], test_point[1]);
			}
			else if ((above_line(point2, point3, test_point) == line_3_above) && above_line(point0, point3, test_point) != line_4_above && above_line(point1, point2, test_point) != line_2_above) {
				count[5]++;
				totx[5] = totx[5] + test_point[0];
				toty[5] = toty[5] + test_point[1];
				std::cout << "area 6" << endl;
				pointFile << test_point_x << "," << test_point_y << "," << ",6" << endl;
				sum_of_dist_from_line[5] = sum_of_dist_from_line[5] + distance_p2p(point2[0], point2[1], test_point[0], test_point[1]);
			}
			else if ((above_line(point0, point1, test_point) != line_1_above) && above_line(point2, point3, test_point) != line_3_above && above_line(point3, point0, test_point) == line_4_above) {
				count[7]++;
				totx[7] = totx[7] + test_point[0];
				toty[7] = toty[7] + test_point[1];
				std::cout << "area 8" << endl;
				pointFile << test_point_x << "," << test_point_y << "," << ",8" << endl;
				sum_of_dist_from_line[7] = sum_of_dist_from_line[7] + distance_p2p(point3[0], point3[1], test_point[0], test_point[1]);
			}

		}
		double meanx[8] = { totx[0] / count[0],totx[1] / count[1], totx[2] / count[2], totx[3] / count[3], totx[4] / count[4], totx[5] / count[5], totx[6] / count[6], totx[7] / count[7] };
		double meany[8] = { toty[0] / count[0],toty[1] / count[1], toty[2] / count[2], toty[3] / count[3], toty[4] / count[4], toty[5] / count[5], toty[6] / count[6], toty[7] / count[7] };
		double sum_dist[8] = { 0,0,0,0,0,0,0,0 };
		
		
		for (int itr = 0; itr < vector_of_points.size(); itr++)
		{
			double test_point_x = vector_of_points[itr][0];
			double test_point_y = vector_of_points[itr][1];
			double test_point[2] = { test_point_x,test_point_y };
			std::cout << "for" << endl;
			if ((above_line(point0, point1, test_point) == line_1_above) && above_line(point0, point3, test_point) == line_4_above) {
				sum_dist[0] = sum_dist[0] + distance_p2p(meanx[0], meany[0], test_point[0], test_point[1]);
			}
			else if ((above_line(point1, point2, test_point) == line_2_above) && above_line(point0, point1, test_point) == line_1_above) {
				sum_dist[2] = sum_dist[2] + distance_p2p(meanx[2], meany[2], test_point[0], test_point[1]);
			}
			else if ((above_line(point2, point3, test_point) == line_3_above) && above_line(point1, point2, test_point) == line_2_above) {
				sum_dist[4] = sum_dist[4] + distance_p2p(meanx[4], meany[4], test_point[0], test_point[1]);
			}
			else if ((above_line(point2, point3, test_point) == line_3_above) && above_line(point0, point3, test_point) == line_4_above) {
				sum_dist[6] = sum_dist[6] + distance_p2p(meanx[6], meany[6], test_point[0], test_point[1]);
			}
			else if ((above_line(point0, point1, test_point) == line_1_above) && above_line(point0, point3, test_point) != line_4_above && above_line(point1, point2, test_point) != line_2_above) {
				sum_dist[1] = sum_dist[1] + distance_p2p(meanx[1], meany[1], test_point[0], test_point[1]);
			}
			else if ((above_line(point0, point1, test_point) != line_1_above) && above_line(point2, point3, test_point) != line_3_above && above_line(point1, point2, test_point) == line_2_above) {
				sum_dist[3] = sum_dist[3] + distance_p2p(meanx[3], meany[3], test_point[0], test_point[1]);
			}
			else if ((above_line(point2, point3, test_point) == line_3_above) && above_line(point0, point3, test_point) != line_4_above && above_line(point1, point2, test_point) != line_2_above) {
				double disssst= distance_p2p(meanx[5], meany[5], test_point[0], test_point[1]);
				sum_dist[5] = sum_dist[5] + distance_p2p(meanx[5], meany[5], test_point[0], test_point[1]);
			}
			else if ((above_line(point0, point1, test_point) != line_1_above) && above_line(point2, point3, test_point) != line_3_above && above_line(point3, point0, test_point) == line_4_above) {
				sum_dist[7] = sum_dist[7] + distance_p2p(meanx[7], meany[7], test_point[0], test_point[1]);
			}
		}
		
		//double var[8] = { sumsqwer[0] / count[0] , sumsqwer[1] / count[1] ,sumsqwer[2] / count[2] ,sumsqwer[3] / count[3] ,sumsqwer[4] / count[4] ,sumsqwer[5] / count[5] ,sumsqwer[6] / count[6] ,sumsqwer[7] / count[7] };
		double* var = sum_dist;
		double max = max_in_arrey(var);
		int index = find(var, var + 8, max) - var;
		double point_to_go[2] = { meanx[index], meany[index] };
		for (int i = 0; i < 8; i++) {
			if ((var[i] > 0.7* max) && count[i]>0.7* count[index]) {
				pointFile << endl << endl << meanx[i] << "," << meany[i] << "," << i+1 << endl;
			}
		}
		//pointFile << endl << endl << meanx[index] << "," << meany[index] << "," << index << endl;
		
		pointFile << endl << endl <<endl;

		double max_new = max_in_arrey(sum_of_dist_from_line);
		int index_new = find(sum_of_dist_from_line, sum_of_dist_from_line + 8, max_new) - sum_of_dist_from_line;
		double point_to_go_new[2] = { meanx[index_new], meany[index_new] };
		for (int i = 0; i < 8; i++) {
			if ((sum_of_dist_from_line[i] > 0.7 * max_new) && count[i] > 0.7 * count[index_new]) {
				pointFile << endl << endl << meanx[i] << "," << meany[i] << "," << i+1 << endl;
			}
		}

			/*
			if (above_line(point0, point3, test_point) && !above_line(point0, point1, test_point)) {
				//area 1
				std::cout << "area 1" << endl;
				pointFile << test_point_x <<","<< test_point_y << "," << ",1" << endl;
			}
			else if (above_line(point0, point3, test_point) && above_line(point0, point1, test_point) && !above_line(point1, point2, test_point)) {
				//area 2
				std::cout << "area 2" << endl;
				pointFile << test_point_x << "," << test_point_y << "," << ",2" << endl;
			}
			else if (above_line(point1, point2, test_point) && above_line(point1, point0, test_point)) {
				//area 3
				std::cout << "area 3" << endl;
				pointFile << test_point_x << "," << test_point_y << "," << ",3" << endl;
			}
			else if (!above_line(point1, point0, test_point) && above_line(point1, point2, test_point) && above_line(point2, point3, test_point)) {
				//area 4
				std::cout << "area 4" << endl;
				pointFile << test_point_x << "," << test_point_y << "," << ",4" << endl;
			}
			else if (!above_line(point2, point3, test_point) && above_line(point1, point2, test_point)) {
				//area 5
				std::cout << "area 5" << endl;
				pointFile << test_point_x << "," << test_point_y << "," << ",5" << endl;
			}
			else if (!above_line(point2, point1, test_point) && !above_line(point2, point3, test_point) && above_line(point3, point0, test_point)) {
				//area 6
				std::cout << "area 6" << endl;
				pointFile << test_point_x << "," << test_point_y << "," << ",6" << endl;
			}
			else if (!above_line(point3, point0, test_point) && !above_line(point3, point2, test_point)) {
				//area 7
				std::cout << "area 7" << endl;
				pointFile << test_point_x << "," << test_point_y << "," << ",7" << endl;
			}
			else if (above_line(point3, point2, test_point) && !above_line(point3, point0, test_point) && !above_line(point0, point1, test_point)) {
				//area 8
				std::cout << "area 8" << endl;
				pointFile << test_point_x << "," << test_point_y << "," << ",8" << endl;
			}
		}
		*/
			return 1;
}

int write_to_file(string myFilepath) {
	string filee = myFilepath + "new.csv";
	std::cout << filee;
	ofstream pointFile;
	pointFile.open(filee);
	if (pointFile.fail()) {
		cerr << "unable open file" << myFilepath << endl;
		return 0;
	}
	for (int itr = 0; itr < vector_of_points.size(); itr++)
	{
		for (int itr2 = 0; itr2 < 5; itr2++) {
			pointFile << vector_of_points[itr][itr2] << ",";
		}
		pointFile << endl;
	}
	pointFile.close();
}
int write_to_file_delete_point(string myFilepath) {
	string filee = myFilepath + "new.csv";
	std::cout << filee;
	ofstream pointFile;
	pointFile.open(filee);
	if (pointFile.fail()) {
		cerr << "unable open file" << myFilepath << endl;
		return 0;
	}
	for (int itr = 0; itr < vector_of_delete_points.size(); itr++)
	{
		for (int itr2 = 0; itr2 < 5; itr2++) {
			pointFile << vector_of_delete_points[itr][itr2] << ",";
		}
		pointFile << endl;
	}
	pointFile.close();
}
int write_to_file_above_point(string myFilepath) {
	string filee = myFilepath + "new.csv";
	std::cout << filee;
	ofstream pointFile;
	pointFile.open(filee);
	if (pointFile.fail()) {
		cerr << "unable open file" << myFilepath << endl;
		return 0;
	}
	for (int itr = 0; itr < vector_of_above_points.size(); itr++)
	{
		for (int itr2 = 0; itr2 < 5; itr2++) {
			pointFile << vector_of_above_points[itr][itr2] << ",";
		}
		pointFile << endl;
	}
	pointFile.close();
}
int write_to_file_inside_point(string myFilepath) {
	string filee = myFilepath + "new.csv";
	std::cout << filee;
	ofstream pointFile;
	pointFile.open(filee);
	if (pointFile.fail()) {
		cerr << "unable open file" << myFilepath << endl;
		return 0;
	}
	for (int itr = 0; itr < vector_of_inside_points.size(); itr++)
	{
		for (int itr2 = 0; itr2 < 5; itr2++) {
			pointFile << vector_of_inside_points[itr][itr2] << ",";
		}
		pointFile << endl;
	}
	pointFile.close();
}

int write_to_file_for_python(string myFilepath) {
	string filee = myFilepath + "for_python.csv";
	std::cout << filee;
	ofstream pointFile;
	pointFile.open(filee);
	if (pointFile.fail()) {
		cerr << "unable open file" << myFilepath << endl;
		return 0;
	}
	for (int itr = 0; itr < vector_of_c_o_m_points.size(); itr++)
	{
		for (int itr2 = 0; itr2 < 3; itr2++) {
			pointFile << vector_of_c_o_m_points[itr][itr2] << ",";
		}
		pointFile << endl;
	}
	pointFile.close();
}

int write_to_file_for_python_midian(string myFilepath) {
	string filee = myFilepath + "for_python_midian.csv";
	std::cout << filee;
	ofstream pointFile;
	pointFile.open(filee);
	if (pointFile.fail()) {
		cerr << "unable open file" << myFilepath << endl;
		return 0;
	}
	for (int itr = 0; itr < vector_of_c_o_m_points_midians.size(); itr++)
	{
		for (int itr2 = 0; itr2 < 2; itr2++) {
			pointFile << vector_of_c_o_m_points_midians[itr][itr2] << ",";
		}
		pointFile << endl;
	}
	pointFile.close();
}

int write_to_file_for_python_max(string myFilepath) {
	string filee = myFilepath + "for_python_max.csv";
	std::cout << filee;
	ofstream pointFile;
	pointFile.open(filee);
	if (pointFile.fail()) {
		cerr << "unable open file" << myFilepath << endl;
		return 0;
	}
	for (int itr = 0; itr < vector_of_c_o_m_points_max_dist.size(); itr++)
	{
		for (int itr2 = 0; itr2 < 3; itr2++) {
			pointFile << vector_of_c_o_m_points_max_dist[itr][itr2] << ",";
		}
		pointFile << endl;
	}
	pointFile.close();
}

int write_to_file_for_python_z_filterd(string myFilepath) {
	string filee = myFilepath + "for_python_z_filterd.csv";
	std::cout << filee;
	ofstream pointFile;
	pointFile.open(filee);
	if (pointFile.fail()) {
		cerr << "unable open file" << myFilepath << endl;
		return 0;
	}
	for (int itr = 0; itr < vector_of_z_filterd_points.size(); itr++)
	{
		for (int itr2 = 0; itr2 < 3; itr2++) {
			pointFile << vector_of_z_filterd_points[itr][itr2] << ",";
		}
		pointFile << endl;
	}
	pointFile.close();
}



/*

double mean(double arr[], int size) {
	int sum = 0;
	for (int i = 0; i < size; i++)
		sum += arr[i];
	return (double)sum / (double)size;
}

double median(double arr[], int size) {
	sort(arr, arr + size);
	if (size % 2 != 0)
		return (double)arr[size / 2];
	return (double)(arr[(size - 1) / 2] + arr[size / 2]) / 2.0;
}*/

int main() {
	/*
	std::vector<Point> point_from_file = getPointsFromFile(myFilepath);
	std::vector<Point> point_of_corners_room = leastSquaresPolygon(point_from_file, 4, 1000);
	double xxxx[4] = { point_of_corners_room[2].x,  point_of_corners_room[3].x,  point_of_corners_room[0].x,  point_of_corners_room[1].x};
	double yyyy[4] = { point_of_corners_room[2].y,  point_of_corners_room[3].y,  point_of_corners_room[0].y,  point_of_corners_room[1].y};
	double p_1[2] = { point_of_corners_room[0].x , point_of_corners_room[0].y };
	double p_2[2] = { point_of_corners_room[1].x , point_of_corners_room[1].y };
	double p_3[2] = { point_of_corners_room[2].x , point_of_corners_room[2].y };
	double p_4[2] = { point_of_corners_room[3].x , point_of_corners_room[3].y };
	*/


	// dani office
	/*
	double xxxx[4] = { -1.37186,-0.0791353,1.26225,-0.112547 };
	double yyyy[4] = { -0.0426986,1.25339,0.191487,-0.916485 };
	double p_1[2] = { -1.37186,-0.0426986 };
	double p_2[2] = { -0.0791353 ,1.25339 };
	double p_3[2] = { 1.26225, 0.191487 };
	double p_4[2] = { -0.112547, -0.916485 };
	*/
	//std::vector< vector <double>> poligon_points = { { -1.37186,-0.0426986 }, { -0.0791353 ,1.25339 }, { 1.26225, 0.191487 }, { -0.112547, -0.916485 } };

	//std::vector< vector <double>> poligon_points = { {-1.0744 ,   0.524587} ,{0.150608 ,-0.509993} ,{0.615496  ,1.02422} ,{0.463464 , 1.08374} };
	//std::vector< vector <double>> poligon_points = { {-0.992008 ,  0.230646} ,{-0.0386762 ,- 0.338912} ,{0.57527  ,  1.0491} ,{-0.398974 ,  1.02715} };

	//std::vector< vector <double>> poligon_points = { {-0.352449  , 1.60134 } ,{-1.90595   , 0.0189554} ,{-0.940565 ,- 1.46735} ,{1.11029, - 1.11824} };


//	std::vector< vector <double>> poligon_points = { {-0.56226,-0.692942} ,{0.329611, 1.05678} ,{1.52248,0.233202} ,{1.45462,0.347838} };

//	std::vector< vector <double>> poligon_points = { {0.0460114 , 1.25309} ,{-1.38163 ,-0.145632} ,{0.953953 ,-0.817814} ,{1.35678  , 0.00933059} };
	
	//std::vector< vector <double>> poligon_points = { {-1.00239 ,  0.200389} ,{0.357456 ,- 1.3409} ,{1.30465 ,- 0.157476} ,{0.416672,  0.890106} };
	
	//lab tau close windos
	//std::vector< vector <double>> poligon_points = { {1.65684,-0.175033  } ,{ 0.160032,1.34744 } ,{-0.920474,0.404124 } ,{ 0.618327,-1.56805 } };

	std::vector< vector <double>> poligon_points = { {-0.288811 , 0.965095 } ,{ -0.782646, - 0.418644 } ,{ 0.152679 ,- 0.634533 } ,{ 0.494078 , 0.623947 } };


	/*
	// dani office corapted
	double xxxx[4] = { -1.0326 , -0.059393, 0.723843, -0.563789 };
	double yyyy[4] = { -0.343463 ,0.736608, 0.226765, -2.40474 };
	double p_1[2] = { -1.0326 ,-0.343463 };
	double p_2[2] = { -0.059393,0.736608 };
	double p_3[2] = { 0.723843, 0.226765 };
	double p_4[2] = { -0.563789,  -2.40474 };
	*/

	//lab tau close windos
   /*
   double p_1[2] = {1.65684,-0.175033  };
   double p_2[2] = { 0.160032,1.34744 };
   double p_3[2] = {-0.920474,0.404124 };
   double p_4[2] = { 0.618327,-1.56805 };

   */
   //lab tau close windos corapted 2
	//std::vector< vector <double>> poligon_points = { { 0.392053 , 1.3129 } , { -0.763608 , 0.569624 } , { 0.662097 , -1.4964 } , { 0.993997,-1.23056 } };
	//lab tau close windos corapted -0.1 out -0.25 in 
	//std::vector< vector <double>> poligon_points = { { 0.378838, 1.33158 }, { -0.695229 , 0.672273 }, { -0.649756 ,-0.157871 }, { 0.797173 ,-0.87033 }};
	
	//std::vector< vector <double>> poligon_points = { {0.906867, 0.982045 },{-0.827797, 0.565665},{-0.0991488, -0.533653},{1.38969 ,-0.452814} };
	//liam brader 2
	//std::vector< vector <double>> poligon_points = { {-0.586858 ,-0.0909506},{0.434287 ,-0.589891},{0.348398 ,  1.14118},{-0.34489  , 1.13555} };
	//liam pernts room
	//std::vector< vector <double>> poligon_points = { { 0.0572851, 1.10162 }, { -0.580873 ,-0.078987 }, { -0.473114 ,-0.916499 }, { 3.68058 ,-0.882346 } };
	//liam pernts room 90% close to c o m
	//std::vector< vector <double>> poligon_points = { { 0.233885 , 1.15451 },{-0.874952, -0.350772},{0.151092 ,-1.30745},{1.04194,-0.105419} };
	//Hilis room 90% close to c o m
	//std::vector< vector <double>> poligon_points = { { 1.06402, 0.389744},{-0.506991, 1.10237},{-0.34166, -0.173038}, { -0.032297, -0.843275 }};
   //lab tau close windos corapted + ronaliza 
	/*
   //1
	double p_1[2] = { -0.97493035 ,- 0.41383338 };
	double p_2[2] = { 0.67047879, - 1.4378464 };
	double p_3[2] = { 0.72230191,  0.8309133 };
	double p_4[2] = { -0.74396516,  0.56061796 };

	
	//2
	double p_1[2] = { -0.92972125 ,-0.55863289 };
	double p_2[2] = { 0.71381859, -1.40094786 };
	double p_3[2] = { 0.72230191 , 0.8309133 };
	double p_4[2] = { -0.59596764 , 0.68558234 };
;*/



   //dany ofice corapted 2
   /*
   double p_1[2] = { 0.937768,0.569714 };
   double p_2[2] = { 0.774104,0.65986 };
   double p_3[2] = { -0.772527,-0.807225};
   double p_4[2] = { 0.51558,-0.0584733 };

   */

   //dany ofice corapted 3
	/*
	double p_1[2] = { -1.3438,0.22018 };
	double p_2[2] = { -0.793295,-2.72423 };
	double p_3[2] = { 0.9291,0.713917 };
	double p_4[2] = { 0.185741,0.907421 };

	*/
	
	//dany ofice corapted 4 + ronaliza 
	/*
	double p_1[2] = { -0.35312364 , 0.91991854 };
	double p_2[2] = { -1.0229017 ,- 0.4769869 };
	double p_3[2] = { 0.53390619, - 0.5725443 };
	double p_4[2] = { 1.17386809 , 0.2710088 };

	*/
	/*
	double yyyy[4] = { -0.67145956,0.35745591, 1.31013, 0.131239 };
	double xxxx[4] = { -0.03647424,-1.3409003,0.1036421,0.79440746 };
	double p_3[2] = { -0.03647424 ,-0.67145956 };
	double p_4[2] = { -1.3409003 ,0.35745591};
	double p_1[2] = { 0.1036421, 1.31013 };
	double p_2[2] = { 0.79440746,0.131239 };
	*/

	/*
	double xxxx[4] = {0.328822,-0.0160304,-0.107277,0.186757};
	double yyyy[4] = {1.1512,1.3216,0.0865174,0.0622394};
	double p_1[2] = { 0.328822,1.1512 };
	double p_2[2] = { -0.0160304,1.3216 };
	double p_3[2] = { -0.107277,0.0865174 };
	double p_4[2] = { 0.186757 ,0.0622394 };
	*/
	string myFilepath = "pointData0.csv";
	//file_to_vector_with_z(myFilepath);
	//delete_far_frome_z();
	//write_to_file_for_python_z_filterd("C:\\Users\\Daniel\\source\\repos\\Project_tello\\Project_tello\\");
	file_to_vector(myFilepath);
	std::vector<double> c_o_m = center_of_mass();
	cout << endl << endl <<"c_o_m =" << c_o_m[0] << " "<<  c_o_m[1] << endl << endl << endl;

	delete_far_frome_c_o_m(c_o_m);
	write_to_file_for_python("");

	//delete_far_frome_c_o_m_with_midian(c_o_m);
	//write_to_file_for_python_midian("C:\\Users\\Daniel\\source\\repos\\Project_tello\\Project_tello\\");
	
	delete_far_frome_c_o_m_with_max_dist(c_o_m,2);
	write_to_file_for_python_max("");

	




//	double xxxx[4] = { p_1[0], p_2[0], p_3[0], p_4[0] };
//	double yyyy[4] = { p_1[1], p_2[1], p_3[1], p_4[1] };
	checkInsidePoligon( poligon_points , 4);
	/*
	//////debug//////////////////////////////////////////////////////
	double p_1[2] = { poligon_points[0][0], poligon_points[0][1] };
	double p_2[2] = { poligon_points[1][0], poligon_points[1][1] };
	double p_3[2] = { poligon_points[2][0], poligon_points[2][1] };
	double p_4[2] = { poligon_points[3][0], poligon_points[3][1] };
	delet_wall_points_for_one_line(p_1, p_2);
	write_to_file("1");
	write_to_file_delete_point("1");
	write_to_file_above_point("1");
	delet_wall_points_for_one_line(p_2, p_3);
	write_to_file("2");
	write_to_file_delete_point("2");
	write_to_file_above_point("2");
	delet_wall_points_for_one_line(p_3, p_4);
	write_to_file("3");
	write_to_file_delete_point("3");
	write_to_file_above_point("3");
	delet_wall_points_for_one_line(p_4, p_1);
	write_to_file("4");
	write_to_file_delete_point("4");
	write_to_file_above_point("4");
	delet_inside();
	write_to_file("orginal");
	write_to_file_delete_point("deletall");
	write_to_file_inside_point("inside");
	//////debug//////////////////////////////////////////////////////
	*/

	delet_wall_points(4, poligon_points);
	write_to_file("pointData0.csv");

	double x = (poligon_points[0][0] + poligon_points[1][0] + poligon_points[2][0] + poligon_points[3][0]) / 4;
	double y = (poligon_points[0][1] + poligon_points[1][1] + poligon_points[2][1] + poligon_points[3][1]) / 4;
	double midel_point[2] = { x, y };
	calc_exits_point_sqwer(poligon_points, "pointData0.csv", midel_point);
	return 0;
}




