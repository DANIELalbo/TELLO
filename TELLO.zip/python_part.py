#import matplotlib as plt
import matplotlib.pyplot as plt
import csv
import numpy as np
#import pyplot as plt
#import scipy as sc 
from scipy.spatial import ConvexHull





def point_in_polygon(polygon, point):
    """
    Raycasting Algorithm to find out whether a point is in a given polygon.
    Performs the even-odd-rule Algorithm to find out whether a point is in a given polygon.
    This runs in O(n) where n is the number of edges of the polygon.
     *
    :param polygon: an array representation of the polygon where polygon[i][0] is the x Value of the i-th point and polygon[i][1] is the y Value.
    :param point:   an array representation of the point where point[0] is its x Value and point[1] is its y Value
    :return: whether the point is in the polygon (not on the edge, just turn < into <= and > into >= for that)
    """

    # A point is in a polygon if a line from the point to infinity crosses the polygon an odd number of times
    odd = False
    # For each edge (In this case for each point of the polygon and the previous one)
    i = 0
    j = len(polygon) - 1
    while i < len(polygon) - 1:
        i = i + 1
        # If a line from the point into infinity crosses this edge
        # One point needs to be above, one below our y coordinate
        # ...and the edge doesn't cross our Y corrdinate before our x coordinate (but between our x coordinate and infinity)

        if (((polygon[i][1] > point[1]) != (polygon[j][1] > point[1])) and (point[0] < (
                (polygon[j][0] - polygon[i][0]) * (point[1] - polygon[i][1]) / (polygon[j][1] - polygon[i][1])) +
                                                                            polygon[i][0])):
            # Invert odd
            odd = not odd
        j = i
    # If the number of crossings was odd, the point is in the polygon
    return odd











def file_to_np_arrey (file_name) :
    data = np.array ([[0,0]])
    with open(file_name) as csv_file:       
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            
            print (row)
            data = np.append(data, [[float(row[0]),float(row[1])]], axis = 0)
            line_count += 1
        print(f'Processed {line_count} lines.')
    return data

def distance_between_point_and_segment(x_point, y_point, x_segment_1, y_segment_1, x_segment_2, y_segment_2):
    side_difference_x_1 = x_point - x_segment_1
    side_difference_y_1 = y_point - y_segment_1
    segment_difference_x = x_segment_2 - x_segment_1
    segment_difference_y = y_segment_2 - y_segment_1

    dot = side_difference_x_1 * segment_difference_x + side_difference_y_1 * segment_difference_y
    len_sq = segment_difference_x * segment_difference_x + segment_difference_y * segment_difference_y
    param = -1
    if len_sq != 0:  # in case of 0 length line
        param = dot / len_sq

    if param < 0:
        xx = x_segment_1
        yy = y_segment_1
    elif param > 1:
        xx = x_segment_2
        yy = y_segment_2

    else:
        xx = x_segment_1 + param * segment_difference_x
        yy = y_segment_1 + param * segment_difference_y

    distance_x = x_point - xx
    distance_y = y_point - yy
    return np.sqrt(distance_x * distance_x + distance_y * distance_y)

def distance_to_polygon(polygon, point, return_min=False):
    dists = []
    k = len(polygon)

    for i in range(len(polygon)):
        #d = np.linalg.norm(polygon[i] - point)
        d = distance_between_point_and_segment(point[0], point[1], polygon[i][0], polygon[i][1], polygon[(i+1)%k][0], polygon[(i+1)%k][1])
        dists.append(d**2)
    """for i in range(len(polygon)):
        #d_side = np.linalg.norm(np.cross(polygon[i] - polygon[(i+1)%k], polygon[(i+1)%k] - point)) / np.linalg.norm(polygon[i] - polygon[(i+1)%k])
        d_ver1 = np.linalg.norm(polygon[i] - point)
        d_ver2 = np.linalg.norm(polygon[(i+1)%k] - point)
        d = min([d_side, d_ver1, d_ver2])
        dists.append(d**2)"""
    """for j in range(len(polygon)):
        d = np.linalg.norm(polygon[j] - point)"""
    if len(dists) == 0:
        print("a")

    if return_min:
        return min(dists), np.argmin(dists)
    else:
        return min(dists)

def ES(data, k, iter, weights=None):
    print (data)
    #weights = np.ones([len(data)])
    min_cost = np.inf
    best_polygon = None

    indices = np.arange(len(data))

    for i in range(iter):
        sample_indices = np.random.choice(indices, k, replace=False)
        sample = data[sample_indices, :]
        try:
            convex_hull_sample = ConvexHull(sample)
        except:
            continue
        convex_hull_sample_cc = []
        for index in convex_hull_sample.vertices:
            convex_hull_sample_cc.append(np.array([sample[index, 0], sample[index, 1]]))
        polygon = np.array(convex_hull_sample_cc)
        if len(polygon) != k:
            continue
        cost = 0
        if weights is not None:
            for point, weight in zip(data, weights):
                cost += weight * distance_to_polygon(polygon, point)
        else:
            for point in data:
                ##print(point_in_polygon(polygon,point))
                ##print(point_in_polygon(polygon,point) == False)
                ##if point_in_polygon(polygon,point) == False:
                cost += distance_to_polygon(polygon, point)

        if cost < min_cost:
            min_cost = cost
            best_polygon = polygon
    plt.scatter(data[:, 0], data[:, 1])
    """for i in range(len(polygon)):
        plt.plot([best_polygon[i][0], best_polygon[(i + 1) % k][0]],
                [best_polygon[i][1], best_polygon[(i + 1) % k][1]],
                color='red', linewidth=3)"""
    for i in range(len(best_polygon)):
        plt.plot([best_polygon[i][0], best_polygon[(i+1)%k][0]], [best_polygon[i][1], best_polygon[(i+1)%k][1]], color='red')
    """plt.plot(data[best_polygon.vertices, 0], data[best_polygon.vertices, 1], 'r', lw=2)"""
    """plt.plot([data[best_polygon.vertisces[0], 0], data[best_polygon.vertices[len(best_polygon.points) - 1], 0]],
             [data[best_polygon.vertices[0], 0], data[best_polygon.vertices[len(best_polygon.points) - 1], 0]])"""
    #plt.plot(data[best_polygon.vertices[0], 0], data[best_polygon.vertices[0], 1], 'ro')
    plt.show()
    print (best_polygon)
    return best_polygon, min_cost


    

#data = file_to_np_arrey("for_python.csv")
data = file_to_np_arrey("for_python_max.csv")
#data = file_to_np_arrey("pointData0.csv")
pionts = ES(data, 4, 30000)


#convex_hull_sample = ConvexHull(sample)
#convex_hull_sample_cc = []
#for index in convex_hull_sample.vertices:
#    convex_hull_sample_cc.append(np.array([sample[index, 0], sample[index, 1]]))
#for i in range(len(best_polygon)):
#    plt.plot([best_polygon[i][0], best_polygon[(i+1)%len(best_polygon)][0]], [best_polygon[i][1], best_polygon[(i+1)%len(best_polygon)][1]], color='red')

#plt.show()
